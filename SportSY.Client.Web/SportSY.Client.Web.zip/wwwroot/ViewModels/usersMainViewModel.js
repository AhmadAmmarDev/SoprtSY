﻿(function () {
    angular.module("sportSy").controller("usersMainViewModel", function ($scope) {
        $scope.first = "Ahmad Ammar user";
    });
}());