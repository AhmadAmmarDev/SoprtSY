﻿$("#acceptTeamMembershipButton").click(function () {
    $.post
});